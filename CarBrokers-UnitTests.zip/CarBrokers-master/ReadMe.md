Our project is going to be an app that helps customers(people looking to buy a car) and brokers(people who are in contact with car dealers) get in touch.  The customer creates an account and then can add cars they are interested in to their profile.  They select year, model, price,ect and then save that car.  A broker can create an account and then see the cars that customers are interested in buying.  If one of a broker's dealership contacts is selling a car that is desired he can get in touch with that customer to learn more.  This will give customers the comfort of not having to go to a dealership and deal with pushy salesman themeselves.  They can choose the car they want and find someone to sell it to them.

Responsibilities:
Akshay-Contoller, View code
Raymond-Model, DbContext/Migration code

Update-Database -ConfigurationTypeName CarBrokers.Migrations.ApplicationDbContext.Configuration

Update-Database -ConfigurationTypeName CarBrokers.Migrations.CarBrokersContext.Configuration
